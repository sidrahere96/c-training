#include <string>


class Player
{
	public:
		std::string name;
		Player();
		int id,runsScored,ballsPlayed,ballsBowled,runsGiven,wicketsTaken;

};
